# Assignment - 1

Name - Mahika Jain

Roll No. - 2021101096

## Q1 

GITHUB REPO LINK: https://github.com/mahikajain1101/Iss_assignment1.git

Q1. 
    Both parts are included in one shell script file named Q1.sh

    Commands:
        chmod +x ./q1.sh
        ./q1.sh

    Input:
        N.A.

    Output:
        Displayed on Terminal (part a and b separated by spaces)

Q2.
    Included in one shell script file named Q2.sh

    Commands:
        chmod +x ./q2.sh
        ./q2.sh

    Input:
        N.A.

    Output:
        Output is saved in a file named speech.txt

Q3.
    All parts are included in one shell script file named Q3.sh

    Commands:
        chmod +x ./q3.sh
        ./q3.sh
    
    Input:
        Name of any file
    
    Output:
        Displayed on Terminal (all the parts are separated by spaces)

Q4.
    Included in one shell script named Q4.sh

    Commands:
        chmod +x ./q4.sh
        ./q4.sh

    Input:
        List of numbers with commas to sort

    Output:
        Displayed on Terminal

Q5.
    All parts included in one shell script named Q5.sh

    Commands:
        chmod x ./q5.sh
        ./q5.sh
    
    Input:
        Any String, with even number of letters

    Output:
        Displayed on Terminal (all the parts are separated by spaces)
